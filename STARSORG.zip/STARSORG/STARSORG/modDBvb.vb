﻿Imports System.Data.SqlClient

Module modDBvb

    Public objSQLConn As SqlConnection
    Public objSQLCommand As SqlCommand
    Public gstrConn As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFileName=D:\Development\VisualStudio\WindowsProgramming\project-SultanAbuhaqab\STARSORG\STARSDB.mdf;Integrated Security=True"

End Module
